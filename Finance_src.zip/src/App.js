// cSpell:Ignore obtem

import React, {useState, useEffect} from 'react';
import './App.css';

export default function App() {

  useEffect (() => {
    obtemDados()
  },[])

  const [economia, setEconomia] = useState([])

  async function obtemDados(){
    let url = `http://economia.awesomeapi.com.br/json/all`

    await fetch(url)
    .then(response => response.json())
    .then(data => {
      console.log(data)
      setEconomia(data)
    })
    .catch(function (error){
      console.error(`Houve um erro: ${error}`)
    })
  }

  const listaMoedas = economia.map((xpto) =>
    <tr key={xpto.code}>
      <td>{xpto.pctChange}</td>
      <td>{xpto.bid}</td>
      <td>{xpto.name}</td>
      <td>{xpto.code}</td>
      <td>{xpto.codein}</td>
    </tr>
  )

  return (
    <div className="App">
        <h1>Finance Quotation</h1>
        <table border="1">
        <thead>
          <tr>
            <th>Variação</th>
            <th>Valor Compra</th>
            <th>Moeda</th>
            <th>Mínimo</th>
            <th>Máximo</th>
          </tr>
        </thead>
        <tbody>
          
        </tbody>
        </table>
    </div>
  );
}
